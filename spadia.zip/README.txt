cmd:
iisreset /stop