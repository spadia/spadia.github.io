<?php

$user = 'root';
$pass = '';
$db = 'zerotouch';

$new_sql = new mysqli('localhost', $user, $pass, $db) or die("Unable to connect");

$connect = 1;

?>